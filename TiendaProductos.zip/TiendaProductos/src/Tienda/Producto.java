/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tienda;

/**
 *
 * @author Polut
 */
public class Producto {
    private String nombreP;
    private double precio;
    private int disponibilidad;
    private String categoria;
    private String referencia;
    private String estadoProducto;

    public Producto(String nombreP, double precio, int disponibilidad, String categoria, String referencia, String estadoProducto) {
        this.nombreP = nombreP;
        this.precio = precio;
        this.disponibilidad = disponibilidad;
        this.categoria = categoria;
        this.referencia = referencia;
        this.estadoProducto = estadoProducto;
    }

    public String getNombreP() {
        return nombreP;
    }

    public double getPrecio() {
        return precio;
    }

    public int getDisponibilidad() {
        return disponibilidad;
    }

    public void setDisponibilidad(int disponibilidad) {
        this.disponibilidad = disponibilidad;
    }

    public String getCategoria() {
        return categoria;
    }

    public String getReferencia() {
        return referencia;
    }

    public String getEstadoProducto() {
        return estadoProducto;
    }

    public void setNombreP(String nombreP) {
        this.nombreP = nombreP;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public void setReferencia(String referencia) {
        this.referencia = referencia;
    }

    public void setEstadoProducto(String estadoProducto) {
        this.estadoProducto = estadoProducto;
    }

    @Override
    public String toString() {
        return "Producto: \n" + "Nombre: " + nombreP + " \nprecio: " + precio + "\ndisponibilidad: " + disponibilidad + "\ncategoria: " + categoria + "\nreferencia: " + referencia + "\nestadoProducto: " + estadoProducto ;
    }
    
    
    
}
