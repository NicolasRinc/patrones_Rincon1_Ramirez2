/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tienda;

import java.util.ArrayList;

/**
 *
 * @author Polut
 */
public class Cliente {
    private String nombre;
    private String cc;
    private String direccion;
    private int edad;
    private double fondos;
    private ArrayList<Producto> carrito;
    private ArrayList<Producto> compras;
    private String metodoPago;

    public Cliente(String nombre, String cc, String direccion, int edad, double fondos, ArrayList<Producto> carrito,ArrayList<Producto> compras, String metodoPago) {
        this.nombre = nombre;
        this.cc = cc;
        this.direccion = direccion;
        this.edad = edad;
        this.fondos = fondos;
        this.carrito = new ArrayList<>();
        this.compras = new ArrayList<>();
        this.metodoPago = metodoPago;
    }

    
    public String getNombre() {
        return nombre;
    }

    public String getCc() {
        return cc;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    
    public int getEdad() {
        return edad;
    }

    public double getFondos() {
        return fondos;
    }

    public void setFondos(double fondos) {
        this.fondos = fondos;
    }

    public ArrayList<Producto> getCarrito() {
        return carrito;
    }

    public ArrayList<Producto> getCompras() {
        return compras;
    }

    public void setCompras(ArrayList<Producto> compras) {
        this.compras = compras;
    }

    public void setCarrito(ArrayList<Producto> carrito) {
        this.carrito = carrito;
    }

    
    

    public String getMetodoPago() {
        return metodoPago;
    }

    public void setMetodoPago(String metodoPago) {
        this.metodoPago = metodoPago;
    }

    @Override
    public String toString() {
        return "Cliente: " + "\nNombre: " + nombre + "\nCC: " + cc + "\nDireccion: " + direccion + "\nEdad: " + edad + "\nFondos: " + fondos + "\nCarrito: " + carrito.toString() + "\nMetodoPago: " + metodoPago ;
    }
    
    
}
