/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tienda;

import java.util.ArrayList;

/**
 *
 * @author Polut
 */
public class Proveedor {
    private String nombre;
    private ArrayList<Producto> productos;

    public Proveedor(String nombre, ArrayList<Producto> productos) {
        this.nombre = nombre;
        this.productos = new ArrayList<>();
    }

   

    
    

    public String getNombre() {
        return nombre;
    }

    

    public ArrayList<Producto> getProductos() {
        return productos;
    }

    
    
    
    
}
