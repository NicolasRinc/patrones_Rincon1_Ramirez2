/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tienda;

import java.util.ArrayList;

/**
 *
 * @author Polut
 */
public class CarritoCompra {
    
    private ArrayList<Producto> carritoCompras;

    public CarritoCompra(ArrayList<Producto> carritoCompras) {
        this.carritoCompras = carritoCompras;
    }

    public ArrayList<Producto> getCarritoCompras() {
        return carritoCompras;
    }

    

    
    
    
    
}
