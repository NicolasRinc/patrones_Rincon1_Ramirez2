/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tienda;

import java.util.ArrayList;

/**
 *
 * @author Polut
 */
public class Tienda {
    
    private ArrayList<Producto> productosT;
    

    public Tienda( ArrayList<Producto> productosT) {
        
        this.productosT = new ArrayList<>();
        
    }

    

    

    public ArrayList<Producto> getProductosT() {
        return productosT;
    }

    @Override
    public String toString() {
        return "Productos de la tienda\n" + productosT ;
    }

    
    
    
}
