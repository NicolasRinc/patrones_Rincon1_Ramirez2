/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

import Tienda.*;
import java.util.ArrayList;
import java.util.Scanner;
public class Main {

   
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        
        ArrayList<Cliente> clientes = new ArrayList<>();
        ArrayList<Producto> tienda = new ArrayList<>();
        ArrayList<Producto> compras = new ArrayList<>();
        ArrayList<Producto> productosP = new ArrayList<>();
        ArrayList<Producto> productosT = new ArrayList<>();
        ArrayList<Producto> productos = new ArrayList<>();
        ArrayList<Producto> carro = new ArrayList<>();
        
        Cliente cliente;
        Proveedor proveedor;
        String nombre,nombreProveedor,cc,direccion,metodoPago;
        int edad = 0;
        double fondos ;
        System.out.println("***CREACION DE CLIENTE***");
                System.out.println("Ingrese el nombre");
                nombre = in.next();
                System.out.println("Ingrese la CC");
                cc = in.next();
                System.out.println("Ingrese la direccion");
                direccion = in.next();
                System.out.println("Ingrese la edad");
                edad = in.nextInt();
                System.out.println("Ingrese los fondos del cliente");
                fondos = in.nextDouble();
                System.out.println("Ingrese el metodo de pago");
                metodoPago = in.next();
                cliente = new Cliente(nombre,cc,direccion,edad,fondos,carro,compras,metodoPago);
                clientes.add(cliente);
        System.out.println("CREACION PROVEEDOR");
        System.out.println("Ingrese el nombre");
        nombreProveedor = in.next();
        proveedor = new Proveedor(nombreProveedor,productosP);
            
        
                
                do{
                    
        int opcion;
        int opcion2 = 0;
        
        String nombrep,productoCompra,nombreP,referencia,estadoProducto,categoria;
        int disponibilidad = 0;
        double precio;
        System.out.println("***TIENDA*******");
            System.out.println("Seleccione una opcion");
            System.out.println("1.Ver productos de la tienda");
            System.out.println("2.Opciones proveedor");
            System.out.println("3.Crear producto");
            System.out.println("4.Agregar objetos a carrito");
            System.out.println("5.Ver carrito");
            System.out.println("6.Buscar un producto(visualizacion)");
            System.out.println("7.Comprar lo que hay en el carrito");
            System.out.println("8.Ver cliente");
        
                                  
        opcion = in.nextInt();
        switch(opcion){
            case 1:
                for(Producto p : tienda){
                    System.out.println(p.toString());
                }
                break;
            case 2:
                int NProductos = productosP.size();
                int NVentas = 0;
                System.out.println("***OPCIONES PROVEEDOR***\n");
                System.out.println("Seleccione una opcion\n"
                                  +"1.Agregar producto proveedor\n"
                                  +"2.Quitar productos\n"
                                  +"3.Ver productos"
                                  +"4.Salir");
                opcion2 = in.nextInt();
                
                switch(opcion2){
                    case 1:
                        System.out.println("***CREACION DE PRODUCTO***");
                        System.out.println("Ingrese el nombre de producto");
                            nombreP = in.next();
                        System.out.println("Ingrese el precio del producto");
                            precio = in.nextDouble();
                        System.out.println("Ingrese la disponibilidad del producto");
                            disponibilidad = in.nextInt();
                        System.out.println("Ingrese la categoria del producto");
                            categoria = in.next();
                        System.out.println("Ingrese la referencia del producto");
                            referencia = in.next();
                        System.out.println("Ingrese el estado del producto");
                            estadoProducto = in.next();
                        Producto producto2 = new Producto(nombreP,precio,disponibilidad,categoria,referencia,estadoProducto);
                            productosP.add(producto2);
                            
                            break;
                    case 2:
                        System.out.println("Ingrese nombre del producto a retirar");
                        String retirada = in.next();
                        for(Producto p : productosP){
                            if(retirada.equals(p.getNombreP())){
                                productosP.remove(p);
                            }
                            else{
                                System.out.println("No existe ese producto");
                            }
                        }
                        break;
                    case 3:
                        for(Producto p : productosP){
                            System.out.println(p.toString());
                        }
                        break;
                    case 4:
                        break;
                        
                }
                break;
            case 3:
                System.out.println("***CREACION DE PRODUCTO***");
                System.out.println("Ingrese el nombre de producto");
                nombreP = in.next();
                System.out.println("Ingrese el precio del producto");
                precio = in.nextDouble();
                System.out.println("Ingrese la disponibilidad del producto");
                disponibilidad = in.nextInt();
                System.out.println("Ingrese la categoria del producto");
                categoria = in.next();
                System.out.println("Ingrese la referencia del producto");
                referencia = in.next();
                System.out.println("Ingrese el estado del producto");
                estadoProducto = in.next();
                Producto producto = new Producto(nombreP,precio,disponibilidad,categoria,referencia,estadoProducto);
                Tienda shop = new Tienda(tienda);
                tienda.add(producto);
                break;
            case 4:
                System.out.println("Estos son los productos de la tienda");
                for(Producto p : tienda){
                    System.out.println(p.toString());
                }
                System.out.println("Ingrese el nombre del producto a agregar a carrito");
                productoCompra = in.next();
                for(Producto p : tienda){
                    if(productoCompra.equals(p.getNombreP())){
                        carro.add(p);
                        p.setDisponibilidad(p.getDisponibilidad()-1);
                    }
                    else{
                        System.out.println("El producto no esta");
                    }
                }
                break;
            case 5:
                for(Producto p : carro){
                    System.out.println(p.toString());
                }
                break;
            case 6:
                System.out.println("Ingrese el nombre del producto a buscar");
                String pro = in.next();
                for(Producto p : tienda){
                    if(pro.equals(p.getNombreP())){
                        System.out.println("Detalles del " + p.toString());
                    }
                    else{
                        System.out.println("El producto no esta en la tienda");
                    }
                }
                break;
            case 7:
                for(Producto p : carro){
                    compras.add(p);
                    cliente.setFondos(cliente.getFondos()-p.getPrecio());
                }
                break;
            case 8:
                System.out.println("" + cliente.toString());
                break;
         }
        }while(true);
    }
    
}
